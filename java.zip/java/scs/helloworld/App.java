package scs.helloworld;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	String s1= "hello";
    	s1="world";
    	String s2 = "hello";
        System.out.println( s1 );
    }
}
